<footer>
    <div class="col-md-2 hidden-sm hidden-xs">
        <a href="http://www.mairie9.lyon.fr/" target="_blank"><img src="./assets/img/lyon9eme.png" alt="Logo Lyon 9" id="logolyon9"></a>
    </div>
    <div class="col-md-8 col-sm-12">
        <ul>
            <li><a href="./"><?php echo $json['nav']['home']; ?></a></li>
            <li>|</li>
            <li><a href="./?page=category&main=everyday"><?php echo $json['nav']['everyday']; ?></a></li>
            <li>|</li>
            <li><a href="./?page=category&main=leisures"><?php echo $json['nav']['leisures']; ?></a></li>
            <li>|</li>
            <li><a href="./?page=category&main=culture"><?php echo $json['nav']['culture']; ?></a></li>
            <li>|</li>
            <li><a href="./?page=usefull_links"><?php echo $json['nav']['usefull_links']; ?></a></li>
            <li>|</li>
            <li><a href="./?page=legal_notice"><?php echo $json['nav']['legal_notice']; ?></a></li>
        </ul>
    </div>
    <div class="col-md-2 hidden-sm hidden-xs">
        <a href="http://www.grandlyon.com/" target="_blank"><img src="./assets/img/grandLyon.png" alt="Logo Grand Lyon" id="logograndlyon"></a>
    </div>
    <p class="texte">Mairie du 9e arrondissement - 6 place du Marché 69009 Lyon - 04 72 19 81 81</p>
</footer>